## Server Dictionary Signs

 - [x] Invalid Error [00] / Not Spawn
 - [x] Invalid Error [01] / Offline User.
 - [x] Invalid Error [02] / Message Flood
 - [x] Invalid Error [03] / Nearby Player
 - [x] Invalid Error [04] / Player In Vehicle
 - [x] Invalid Error [05] / Undead Player